if (localStorage.getItem('usuarios') === null){
    localStorage.setItem('usuarios', JSON.stringify([
        {usuario: 'Felix', senha: '123', ptnfacil:'0', ptnmedio:'0', ptndificil:'0'},
        {usuario: 'AnaB', senha: '456', ptnfacil:'0', ptnmedio:'0', ptndificil:'0'},
        {usuario: 'Ronaldo', senha: '2002', ptnfacil:'0', ptnmedio:'0', ptndificil:'0'},
        {usuario: 'Henrique ', senha: '134', ptnfacil:'0', ptnmedio:'0', ptndificil:'0'}
    ]));
}
function getUsuarios(){
    return JSON.parse(localStorage.getItem('usuarios'));
}
function saveUsuarios(usuarios){
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
}
document.getElementById('login').addEventListener('submit', function login(event){
    event.preventDefault();

    var user = document.getElementById('user').value;
    var senha = document.getElementById('senha').value;
    var usuarios = getUsuarios();
    var loginValido = false;
    
    for (var i in usuarios){
        if(user == usuarios[i].usuario && senha == usuarios[i].senha){
            loginValido = true;
            break;
        }
    }

    if(loginValido){
        alert('Login realizado com sucesso');
        location.href = '/jogo/jogo.html';
    }else{
        alert('NickName ou senha incorreto');
    }
});
document.getElementById('registrar').addEventListener('click', function (){
    var user = document.getElementById('user').value;
    var senha = document.getElementById('senha').value;
    var usuarios = getUsuarios();
    var loginExistente = false;

    for (var i in usuarios){
        if(user == usuarios[i].usuario){
            loginExistente = true;
            break;
        }
}
    if(loginExistente){
        alert('Usuário já existe');
    }else{
        usuarios.push({ usuario: user, senha: senha});
        saveUsuarios(usuarios);
        alert('Usuário Registrado')
    }
    
});