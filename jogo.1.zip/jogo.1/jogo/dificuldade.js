let pontuacao = 0;
let tempo = 0;
let bolinha = document.getElementById('bolinha');
let jogo = document.getElementById('jogo');
let apagar = document.getElementById('dificuldade');
let jogarNovamente = document.getElementById('jogaDnovo');
let dific = 0;

jogarNovamente.style.display = 'none';


//Clamp

const min = 50
const max = 80

//Clamp number between two values with the following line:
const clamp = (num, min, max) => Math.min(Math.max(num, min), max)

//

let pontua =[
    {
        jogadores: "",
        senha:"",
        ptnfacil: 0,
        ptnmedio: 0,
        ptndificil: 0

    }
]; 



document.getElementById("facil").addEventListener('click', function() {
    pontuacao = 0;
    ptnfacil = 0;
    tempo = 10;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    dific = 0;

   
});
document.getElementById("medio").addEventListener('click', function() {
    pontuacao = 0;
    ptnmedio = 0;
    tempo = 7;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    dific = 1;
    
});
document.getElementById("dificil").addEventListener('click', function() {
    pontuacao = 0;
    ptndificil = 0;
    tempo = 2;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    dific = 2;
    
    
});



function iniciarJogo() {
    pontuacao = 0;
    jogo.style.display = 'block'; 
    document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
    let intervalId = setInterval(() => {
        if (pontuacao > 0) {
            pontuacao--;
            document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
        } else {
            jogo.style.display = 'none'; 
            clearInterval(intervalId); 
            jogarNovamente.style.display = 'block';
        }
    }, tempo * 1000);
}
    
    
    bolinha.addEventListener('click', () => {
        pontuacao++;
        document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
        bolinha.style.top = `${Math.floor((Math.random() * 50) + 25)}%`;
        //bolinha.style.bottom = ${Math.random() * 100}%;
        bolinha.style.left = `${Math.floor((Math.random() * 50) + 25)}%`;
        //bolinha.style.right = ${Math.random() * 1}%;

        if (dific == 0){
            ptnfacil += 1;
          
        };

        if(dific == 1){
            ptnmedio += 1;
            
        };

        if (dific == 2){
            ptndificil +=1;

           
        };
    
         
            if (pontuacao >= 10) {
                 bolinha.style.backgroundImage = 'url("sol.png")';
                 bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 20) {
                bolinha.style.backgroundImage = 'url("mercurio1.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 30) {
                bolinha.style.backgroundImage = 'url("venus.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 40) {
                bolinha.style.backgroundImage = 'url("terra.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 50) {
                bolinha.style.backgroundImage = 'url("marte.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 60) {
                bolinha.style.backgroundImage = 'url("jupiter.png")';
                bolinha.style.backgroundSize = 'contain';
                bolinha.style.borderImageWidth
            }
            if (pontuacao >= 70) {
                bolinha.style.backgroundImage = 'url("saturno.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 80) {
                bolinha.style.backgroundImage = 'url("urano.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 90) {
                bolinha.style.backgroundImage = 'url("netuno.png")';
                bolinha.style.backgroundSize = 'contain';
            }

        });
    
    
   

document.getElementById('volta').addEventListener('click', function novamente(){
    
    pontuacao = 0;
    jogo.style.display = 'none';
    apagar.style.display = 'block';
    jogarNovamente.style.display = 'none';
    location.reload();

});
document.getElementById('voltar').addEventListener('click', function  (){

    jogo.style.display = 'none';
    apagar.style.display = 'block';
    pontuacao = 0;
    location.reload();
    jogarNovamente.style.display = 'none';
    s
});